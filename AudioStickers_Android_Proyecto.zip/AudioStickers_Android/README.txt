AUDIOSTICKERS - PROYECTO ANDROID INICIAL

Qué incluye esta primera versión:
- Aplicación Android nativa.
- Selector de videos del teléfono (incluye videos descargados de TikTok).
- Extracción de la pista de audio original a un archivo M4A.
- Guardado en Música/AudioStickers y opción para compartir.

Qué NO incluye todavía:
- Conversión del video a sticker animado.
- Recorte visual de duración.
- Un formato que reproduzca audio al tocar un sticker normal dentro de WhatsApp.
WhatsApp no admite que un sticker normal lleve audio reproducible al tocarlo. En esta versión el audio se comparte como archivo aparte.

Cómo generar el APK:
1. Instala Android Studio en un computador.
2. Abre la carpeta AudioStickers como proyecto.
3. Espera a que Gradle sincronice y descargue dependencias.
4. Ve a Build > Build Bundle(s) / APK(s) > Build APK(s).
5. El APK de prueba aparecerá en app/build/outputs/apk/debug/app-debug.apk.

Requisitos: Android Studio reciente, JDK 17 y conexión a Internet durante la primera sincronización.
Este proyecto es código fuente, no un APK compilado.
