package com.audiostickers.app

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer

class MainActivity : Activity() {
    private val pickVideoCode = 41
    private var selectedVideo: Uri? = null
    private lateinit var status: TextView
    private lateinit var extractButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 48, 28, 28)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply {
            text = "AudioStickers 🔊"
            textSize = 30f
            gravity = Gravity.CENTER
        }
        val intro = TextView(this).apply {
            text = "Convierte el sonido de un video en un archivo de audio para compartirlo junto a tu sticker."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val pickButton = Button(this).apply {
            text = "Elegir video"
            setOnClickListener { chooseVideo() }
        }
        extractButton = Button(this).apply {
            text = "Extraer audio"
            isEnabled = false
            setOnClickListener { selectedVideo?.let { extractAudio(it) } }
        }
        status = TextView(this).apply {
            text = "Primero selecciona un video de tu galería o un archivo descargado."
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 12)
        }
        layout.addView(title, matchWrap())
        layout.addView(intro, matchWrap())
        layout.addView(pickButton, matchWrap())
        layout.addView(extractButton, matchWrap())
        layout.addView(status, matchWrap())
        setContentView(layout)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 12 }

    private fun chooseVideo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
        }
        startActivityForResult(intent, pickVideoCode)
    }

    @Deprecated("Uses the compatible document-picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickVideoCode && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                selectedVideo = uri
                extractButton.isEnabled = true
                status.text = "Video seleccionado. Pulsa «Extraer audio»."
            }
        }
    }

    private fun extractAudio(uri: Uri) {
        extractButton.isEnabled = false
        status.text = "Extrayendo audio…"
        Thread {
            try {
                val input = File(cacheDir, "source_video")
                contentResolver.openInputStream(uri)?.use { source ->
                    FileOutputStream(input).use { target -> source.copyTo(target) }
                } ?: throw IllegalStateException("No se pudo abrir el video")

                val output = File(cacheDir, "AudioStickers_audio.m4a")
                val extractor = MediaExtractor()
                extractor.setDataSource(input.absolutePath)
                var audioTrack = -1
                var format: MediaFormat? = null
                for (i in 0 until extractor.trackCount) {
                    val f = extractor.getTrackFormat(i)
                    val mime = f.getString(MediaFormat.KEY_MIME) ?: ""
                    if (mime.startsWith("audio/")) {
                        audioTrack = i
                        format = f
                        break
                    }
                }
                if (audioTrack < 0 || format == null) {
                    extractor.release()
                    throw IllegalStateException("Este video no contiene una pista de audio")
                }
                extractor.selectTrack(audioTrack)
                val muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                val outTrack = muxer.addTrack(format)
                muxer.start()
                val buffer = ByteBuffer.allocate(1024 * 1024)
                val info = android.media.MediaCodec.BufferInfo()
                while (true) {
                    buffer.clear()
                    val size = extractor.readSampleData(buffer, 0)
                    if (size < 0) break
                    info.offset = 0
                    info.size = size
                    info.presentationTimeUs = extractor.sampleTime
                    info.flags = extractor.sampleFlags
                    muxer.writeSampleData(outTrack, buffer, info)
                    extractor.advance()
                }
                muxer.stop()
                muxer.release()
                extractor.release()
                input.delete()
                val savedUri = saveAudio(output)
                runOnUiThread {
                    status.text = "¡Audio extraído! Ya puedes compartirlo."
                    extractButton.isEnabled = true
                    shareAudio(savedUri)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "No se pudo extraer el audio: ${e.message ?: "error"}"
                    extractButton.isEnabled = true
                    Toast.makeText(this, "Error al procesar el video", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun saveAudio(file: File): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, "AudioStickers_${System.currentTimeMillis()}.m4a")
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
            put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/AudioStickers")
        }
        val uri = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("No se pudo guardar el audio")
        contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
        file.delete()
        return uri
    }

    private fun shareAudio(uri: Uri) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "audio/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "Compartir audio"))
    }
}
